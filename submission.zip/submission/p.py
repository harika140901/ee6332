import datetime
import re, sys
import networkx as nx
import numpy as np
from gpkit import Variable, VectorVariable, Model
sys.setrecursionlimit(1000000)
class Gate:
    def __init__(self, name, gate_type, p=0, l=0):
        self.name, self.gate_type, self.inputs, self.outputs = name, gate_type, [], []
        self.p = p
        self.l = l

    def add_input(self, gate):
        if gate not in self.inputs:
            self.inputs.append(gate)
            if self not in gate.outputs: gate.outputs.append(self)

    def add_output(self, gate):
        if gate not in self.outputs:
            self.outputs.append(gate)
            if self not in gate.inputs: gate.inputs.append(self)

class Net:
    def __init__(self, name, source=None, destinations=None):
        self.name, self.source, self.destinations, self.value = name, source, destinations or [], None

    def add_destination(self, gate):
        if gate not in self.destinations: self.destinations.append(gate)

    def set_source(self, gate):
        self.source = gate

class Circuit:
    def __init__(self):
        self.gates, self.nets, self.inputs, self.outputs = {}, {}, [], []
        self.gate_order = []

    def add_gate(self, gate):
        self.gates[gate.name] = gate
        if gate.name not in self.gate_order:
            self.gate_order.append(gate.name)

    def add_net(self, net): self.nets[net.name] = net

    def connect(self, source_gate_name, dest_gate_name, net_name=None):
        source_gate, dest_gate = self.gates.get(source_gate_name), self.gates.get(dest_gate_name)
        if not source_gate or not dest_gate: raise ValueError(f"Cannot connect: gate not found")

        net_name = net_name or f"{source_gate_name}_to_{dest_gate_name}"
        if net_name not in self.nets:
            net = Net(net_name, source_gate, [dest_gate])
            self.add_net(net)
        else:
            net = self.nets[net_name]
            net.set_source(source_gate)
            net.add_destination(dest_gate)

        source_gate.add_output(dest_gate)
        dest_gate.add_input(source_gate)
        return net

    def set_input_gates(self, gate_names): self.inputs = gate_names

    def set_output_gates(self, gate_names): self.outputs = gate_names

    def get_fanouts(self):
        return {gate_name: [g.name for g in gate.outputs] for gate_name, gate in self.gates.items()}
    
    def get_all_paths(self):
        sources = [gn for gn, g in self.gates.items() if not g.inputs]
        sinks = [gn for gn, g in self.gates.items() if not g.outputs]
        all_paths = []

        def dfs(current, path):
            path.append(current)
            if current in sinks:
                all_paths.append(path.copy())
            else:
                for next_gate in self.gates[current].outputs:
                    dfs(next_gate.name, path)
            path.pop()

        for source in sources:
            dfs(source, [])

        return all_paths

    def get_longest_paths(self):
        sources = [gn for gn, g in self.gates.items() if not g.inputs]
        sinks = [gn for gn, g in self.gates.items() if not g.outputs]
        longest_paths, max_length = [], 0

        def find_paths(current, path, visited):
            nonlocal longest_paths, max_length
            visited.add(current); path.append(current)

            if current in sinks:
                path_length = len(path)
                if path_length > max_length: max_length, longest_paths = path_length, [path.copy()]
                elif path_length == max_length: longest_paths.append(path.copy())

            for next_gate in self.gates[current].outputs:
                if next_gate.name not in visited: find_paths(next_gate.name, path, visited)

            path.pop(); visited.remove(current)

        for source in sources: find_paths(source, [], set())
        return longest_paths, max_length

def parse(file_contents):
    circuit = Circuit()
    patterns = {
        'input': re.compile(r'input\s+([^;]+);'),
        'output': re.compile(r'output\s+([^;]+);'),
        'wire': re.compile(r'wire\s+([^;]+);'),
        'gate': re.compile(r'(not|nand|nor)\s+(\w+)\s*\(([^)]+)\);', re.MULTILINE)
    }

    inputs = [inp.strip() for inp in patterns['input'].search(file_contents).group(1).split(',')] if patterns['input'].search(file_contents) else []
    outputs = [out.strip() for out in patterns['output'].search(file_contents).group(1).split(',')] if patterns['output'].search(file_contents) else []
    wires = [wire.strip() for wire in patterns['wire'].search(file_contents).group(1).split(',')] if patterns['wire'].search(file_contents) else []

    for signal_name in inputs + outputs + wires: circuit.add_net(Net(signal_name))

    for gate_match in patterns['gate'].finditer(file_contents):
        gate_type, gate_name = gate_match.group(1).upper(), gate_match.group(2)
        if not any(gate_name.lower().startswith(prefix) for prefix in ['nand', 'nor', 'not']): continue

        ports = [port.strip() for port in gate_match.group(3).split(',')]
        output_port, input_ports = ports[0], ports[1:]

        gate = Gate(gate_name, gate_type)
        circuit.add_gate(gate)

        output_net = circuit.nets.get(output_port) or Net(output_port)
        if output_port not in circuit.nets: circuit.add_net(output_net)
        output_net.set_source(gate)

        for input_port in input_ports:
            input_net = circuit.nets.get(input_port) or Net(input_port)
            if input_port not in circuit.nets: circuit.add_net(input_net)
            input_net.add_destination(gate)

        if output_port in outputs and circuit.gates.get(output_port): circuit.connect(gate_name, output_port)

    for net_name, net in circuit.nets.items():
        if net.source and net.destinations:
            source_gate = net.source
            for dest_gate in net.destinations:
                if source_gate.name != dest_gate.name:
                    is_gate = lambda g: any(g.name.lower().startswith(p) for p in ['nand', 'nor', 'not'])
                    if is_gate(source_gate) and is_gate(dest_gate): circuit.connect(source_gate.name, dest_gate.name, net_name)

    circuit.set_input_gates(inputs)
    circuit.set_output_gates(outputs)
    return circuit

def gates_with_primary_inputs(circuit):
    result = []
    for net_name in circuit.inputs:
        net = circuit.nets.get(net_name)
        if net:
            for gate in net.destinations:
                result.append(gate.name)
    return sorted(set(result))

def gates_with_primary_outputs(circuit):
    result = []
    for net_name in circuit.outputs:
        net = circuit.nets.get(net_name)
        if net and net.source:
            result.append(net.source.name)
    for gate_name, gate in circuit.gates.items():
        if not gate.outputs:
            result.append(gate_name)
    return sorted(set(result))

def analyze_circuit(ckt):
    def get_gate_number(gate_name):
        parts = gate_name.split('_')
        if len(parts) < 2:
            return float('inf')
        num_part = parts[1]
        return int(num_part)

    fanouts_dict = {}
    fanouts = ckt.get_fanouts()
    for gate_name in sorted(fanouts.keys(), key=get_gate_number):
        gate_fanouts = fanouts[gate_name]
        sorted_fanouts = sorted(gate_fanouts, key=get_gate_number) if gate_fanouts else []
        fanouts_dict[gate_name] = sorted_fanouts

    critical_paths_dict = {
        "max_length": 0,
        "paths": []
    }
    longest_paths, max_length = ckt.get_longest_paths()
    if longest_paths:
        critical_paths_dict["max_length"] = max_length
        def get_path_priority(path):
            if not path: return float('inf')
            return get_gate_number(path[0])
        sorted_paths = sorted(longest_paths, key=get_path_priority)
        critical_paths_dict["paths"] = sorted_paths
    return fanouts_dict, critical_paths_dict

logicalEffortDict = {
    ("NAND", 2): 4/3,
    ("NAND", 3): 5/3,
    ("NAND", 4): 2,
    ("NOR", 2): 5/3,
    ("NOR", 3): 7/3,
    ("NOR", 4): 3,
    ("INV", 1): 1,
    ("NOT", 1): 1
}

cload = 1000
max_gate_size = 64

def get_gate_type_and_inputs(gate_name):
    gatenum = gate_name.split("_")[1]
    prefix = gate_name.split("_")[0]
    gate_type = prefix[:-1]
    num_inputs = int(prefix[-1])
    return gate_type.upper(), num_inputs, gatenum

def gates_with_all_primary_inputs(circuit):
    primary_nets = set(circuit.inputs)
    qualifying_gates = []
    
    for gate_name, gate in circuit.gates.items():
        # Find all nets feeding into this gate
        input_nets = [
            net_name for net_name, net in circuit.nets.items()
            if gate in net.destinations
        ]
        
        # Check if all input nets are primary inputs
        if all(net in primary_nets for net in input_nets) and input_nets:
            qualifying_gates.append(gate_name)
    
    return sorted(qualifying_gates)

import numpy as np
from gpkit import Variable, VectorVariable, Model

def compute_global_tmin_node_based(fanouts_dict, critical_paths_dict, inpGates, all_paths, x, gate_index_map, g, p):
    N = len(fanouts_dict)
    Gsize = VectorVariable(N, "x", sign="positive")
    T = VectorVariable(N, "T", sign="positive")
    constraints = []

    # Convert g and p to NumPy arrays if they aren't already
    g = np.array(g)
    p = np.array(p)

    # Input capacitance constraints
    for net in circuit.nets:
        total_cap = 0
        for gate in circuit.nets[net].destinations:
            if gate.name in inpGates and circuit.nets[net].source is None:
                idx = gate_index_map[gate.name]
                total_cap += g[idx] * Gsize[idx]
        if total_cap != 0:
            constraints.append(total_cap <= 50)

    # Primary input constraints (near-zero arrival time with bounds)
    primary_input_gates = []
    for gate_name in inpGates:
        if gate_name in gate_index_map and gate_name in x:
            idx = gate_index_map[gate_name]
            T[idx] = 0
            # constraints += [T[idx] <= 1e-9, T[idx] >= 1e-12]
            primary_input_gates.append(gate_name)

    # Gate timing constraints
    for gate in fanouts_dict:
        idx = gate_index_map[gate]
        input_gates = circuit.gates[gate].outputs

        # Calculate total fanout effort using NumPy
        total_fo_effort = 0
        for fanout in fanouts_dict[gate]:
            if fanout in gate_index_map:
                f_idx = gate_index_map[fanout]
                total_fo_effort += g[f_idx] * Gsize[f_idx]

        # Delay calculation using logical effort formula
        delay = p[idx]
        if total_fo_effort != 0:
            delay += total_fo_effort / Gsize[idx]

        # Arrival time constraints from all inputs
        for input_gate in input_gates:
            input_idx = gate_index_map[input_gate.name]
            constraints.append(T[input_idx] >= T[idx] + delay)

    output_gates = gates_with_primary_outputs(circuit)
    Tmax = Variable("Tmax")
    for gate in output_gates:
        idx = gate_index_map[gate]
        load_delay = cload / Gsize[idx]
        constraints.append(Tmax >= T[idx] + load_delay + p[idx])

    constraints += [Gsize >= 1, Gsize <= max_gate_size]

    m = Model(Tmax, constraints)
    sol = m.solve(verbosity=1)

    GsizeList = np.array(sol["variables"]["x"])
    print('sum of all sizes', np.sum(GsizeList))

    print(f"\nNormalized Optimal Delay: {sol['cost']:.2f}")

    return sol['cost'], GsizeList, sol


def minimum_area_node_based(fanouts_dict, critical_paths_dict, Tspec, alpha, inpGates, x):
    N = len(fanouts_dict)
    Gsize = VectorVariable(N, "x", sign="positive")

    T = VectorVariable(N, "T", sign="positive")
    
    g = [1.0] * N
    p = [2.0] * N  
    gate_index_map = {}

    for gate in fanouts_dict:
        gate_type, num_inputs, _ = get_gate_type_and_inputs(gate)
        idx = int(gate.split("_")[1]) - 1
        gate_index_map[gate] = idx
        g[idx] = logicalEffortDict.get((gate_type, num_inputs), 1.0)
        p[idx] = num_inputs
    
    constraints = []

    for net in circuit.nets:
        total_cap = 0
        for gate in circuit.nets[net].destinations:
            if gate.name in inpGates and circuit.nets[net].source is None:
                idx = gate_index_map[gate.name]
                total_cap += g[idx] * Gsize[idx]
        if total_cap != 0:
            constraints.append(total_cap <= 50)

    primary_input_gates = []
    for gate_name in inpGates:
        if gate_name in gate_index_map and gate_name in x:
            idx = gate_index_map[gate_name]
            T[idx] = 0
            primary_input_gates.append(gate_name)
    

    for gate in fanouts_dict:
        idx = gate_index_map[gate]
        input_gates = circuit.gates[gate].outputs
        

        total_fo_effort = 0
        for fanout in fanouts_dict[gate]:
            if fanout in gate_index_map:
                f_idx = gate_index_map[fanout]
                total_fo_effort += g[f_idx] * Gsize[f_idx]
        
        delay = p[idx]
        if total_fo_effort != 0:
            delay += total_fo_effort / Gsize[idx]
        
        for input_gate in input_gates:
            input_idx = gate_index_map[input_gate.name]
            constraints.append(T[input_idx] >= T[idx] + delay)

    output_gates = gates_with_primary_outputs(circuit)
    for gate in output_gates:
        idx = gate_index_map[gate]
        load_delay = cload / Gsize[idx]
        constraints.append(T[idx] + load_delay + p[idx]<= Tspec)

    constraints += [Gsize >= 1, Gsize <= max_gate_size]
    

    objective = sum(Gsize)
    m = Model(objective, constraints)
    sol = m.solve(verbosity=0)

    GsizeList = [round(float(x), 3) for x in sol["variables"]["x"]]
    
    print(f"\nAlpha: {alpha}")
    print(f"Minimum Area: {sol['cost']:.2f}")

    max_delay = 0
    for gate in output_gates:
        idx = gate_index_map[gate]
        delay = float(sol["variables"]["T"][idx]) + cload/float(sol(Gsize[idx]))
        max_delay = max(max_delay, delay)
    print(f"Actual Maximum Delay: {max_delay:.2f} (Spec: {Tspec:.2f})")
    print(GsizeList)
    return sol['cost'], GsizeList


with open(sys.argv[1], 'r') as f: file_contents = f.read() 

circuit = parse(file_contents)
inpGates = gates_with_primary_inputs(circuit)
all_paths = circuit.get_all_paths()
fanouts_dict, critical_paths_dict = analyze_circuit(circuit)

import math
x = gates_with_all_primary_inputs(circuit)
N = len(fanouts_dict)
g = [1.0] * N
p = [2.0] * N

gate_index_map = {}

for gate in fanouts_dict:
    gate_type, num_inputs, _ = get_gate_type_and_inputs(gate)
    idx = int(gate.split("_")[1]) - 1
    gate_index_map[gate] = idx
    g[idx] = logicalEffortDict.get((gate_type, num_inputs), 1.0)
    p[idx] = num_inputs  

Twall, GsizesList, sol = compute_global_tmin_node_based(fanouts_dict, critical_paths_dict, inpGates, all_paths, x, gate_index_map, g , p)

# Use node-based area minimization for different alpha values
for alpha in [1.05, 1.1, 1.2, 1.3, 1.4, 1.5]:
    minimum_area_node_based(fanouts_dict, critical_paths_dict, Twall*alpha, alpha, inpGates, x)
